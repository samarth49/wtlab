-- Create the database
CREATE DATABASE IF NOT EXISTS bookstore;
USE bookstore;

-- Create books table
CREATE TABLE IF NOT EXISTS books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    image_url VARCHAR(255),
    description TEXT
);

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

-- Insert sample books data
INSERT INTO books (title, author, price, image_url, description) VALUES
('The Great Gatsby', 'F. Scott Fitzgerald', 9.99, 'https://example.com/gatsby.jpg', 'A story of decadence and excess, Gatsby explores the darker aspects of the American Dream.'),
('To Kill a Mockingbird', 'Harper Lee', 12.99, 'https://example.com/mockingbird.jpg', 'A touching story of racial injustice and the loss of innocence in the American South.'),
('1984', 'George Orwell', 10.99, 'https://example.com/1984.jpg', 'A dystopian social science fiction novel and cautionary tale.'),
('Pride and Prejudice', 'Jane Austen', 8.99, 'https://example.com/pride.jpg', 'A romantic novel of manners that follows the character development of Elizabeth Bennet.'),
('The Hobbit', 'J.R.R. Tolkien', 14.99, 'https://example.com/hobbit.jpg', 'A fantasy novel about the adventures of hobbit Bilbo Baggins.'),
('Harry Potter and the Sorcerer''s Stone', 'J.K. Rowling', 15.99, 'https://example.com/harry.jpg', 'The first book in the Harry Potter series, following a young wizard''s adventures.');

-- Add indexes for better performance
ALTER TABLE books ADD INDEX idx_title (title);
ALTER TABLE books ADD INDEX idx_author (author);
ALTER TABLE users ADD INDEX idx_email (email);
