const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
app.use(cors({
  origin: 'http://localhost:5173', // Vite's default port
  credentials: true
}));
app.use(express.json());

// MySQL Connection
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});

db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL database');
  
  // Create books table if it doesn't exist
  const createBooksTable = `
    CREATE TABLE IF NOT EXISTS books (
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      author VARCHAR(255) NOT NULL,
      price DECIMAL(10,2) NOT NULL,
      image_url VARCHAR(255),
      description TEXT
    )
  `;
  
  // Create users table if it doesn't exist
  const createUsersTable = `
    CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      username VARCHAR(255) NOT NULL UNIQUE,
      email VARCHAR(255) NOT NULL UNIQUE,
      password VARCHAR(255) NOT NULL
    )
  `;

  db.query(createBooksTable);
  db.query(createUsersTable);
});

// Routes
// Get all books
app.get('/api/books', (req, res) => {
  db.query('SELECT * FROM books', (err, results) => {
    if (err) {
      console.error('Error fetching books:', err);
      res.status(500).json({ error: err.message });
      return;
    }
    res.json(results);
  });
});

// Register user
app.post('/api/register', async (req, res) => {
  console.log('Received registration request:', req.body);
  const { username, email, password } = req.body;
  
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    
    db.query(
      'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
      [username, email, hashedPassword],
      (err, result) => {
        if (err) {
          console.error('Registration error:', err);
          res.status(500).json({ error: err.message });
          return;
        }
        console.log('Registration successful');
        res.json({ message: 'User registered successfully' });
      }
    );
  } catch (error) {
    console.error('Error during registration:', error);
    res.status(500).json({ error: error.message });
  }
});

// Login user
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  
  db.query(
    'SELECT * FROM users WHERE email = ?',
    [email],
    async (err, results) => {
      if (err) {
        res.status(500).json({ error: err.message });
        return;
      }
      
      if (results.length === 0) {
        res.status(401).json({ error: 'Invalid credentials' });
        return;
      }
      
      const user = results[0];
      const validPassword = await bcrypt.compare(password, user.password);
      
      if (!validPassword) {
        res.status(401).json({ error: 'Invalid credentials' });
        return;
      }
      
      const token = jwt.sign({ userId: user.id }, 'your-secret-key', { expiresIn: '1h' });
      res.json({ token });
    }
  );
});

// Insert sample books
app.post('/api/sample-books', (req, res) => {
  const sampleBooks = [
    {
      title: 'The Great Gatsby',
      author: 'F. Scott Fitzgerald',
      price: 9.99,
      image_url: 'https://via.placeholder.com/200x300',
      description: 'A story of decadence and excess.'
    },
    {
      title: 'To Kill a Mockingbird',
      author: 'Harper Lee',
      price: 12.99,
      image_url: 'https://via.placeholder.com/200x300',
      description: 'A classic of modern American literature.'
    },
    {
      title: '1984',
      author: 'George Orwell',
      price: 10.99,
      image_url: 'https://via.placeholder.com/200x300',
      description: 'A dystopian social science fiction.'
    }
  ];

  const insertQuery = 'INSERT INTO books (title, author, price, image_url, description) VALUES ?';
  const values = sampleBooks.map(book => [book.title, book.author, book.price, book.image_url, book.description]);

  db.query(insertQuery, [values], (err, result) => {
    if (err) {
      console.error('Error inserting sample books:', err);
      res.status(500).json({ error: err.message });
      return;
    }
    console.log('Sample books inserted successfully');
    res.json({ message: 'Sample books added successfully' });
  });
});

// Test route to verify server is working
app.get('/api/test', (req, res) => {
  res.json({ message: 'Server is running!' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
