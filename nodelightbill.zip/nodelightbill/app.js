const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const db = require('./config/database');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

// Add a new consumer
app.post('/api/consumers', async (req, res) => {
  const { name, address, contact_number, email } = req.body;
  try {
    const [result] = await db.execute(
      'INSERT INTO consumer (name, address, contact_number, email) VALUES (?, ?, ?, ?)',
      [name, address, contact_number, email]
    );
    res.json({ id: result.insertId, name, address, contact_number, email });
  } catch (err) {
    console.error('Error in /api/consumers:', err); // Log error for debugging
    res.status(500).json({ error: err.message });
  }
});

// Calculate bill amount
function calculateBill(units) {
  let amount = 0;
  if (units <= 50) {
    amount = units * 3.5;
  } else if (units <= 150) {
    amount = 50 * 3.5 + (units - 50) * 4.0;
  } else if (units <= 250) {
    amount = 50 * 3.5 + 100 * 4.0 + (units - 150) * 5.2;
  } else {
    amount = 50 * 3.5 + 100 * 4.0 + 100 * 5.2 + (units - 250) * 6.5;
  }
  return amount;
}

// Add a billing record and calculate bill
app.post('/api/billing', async (req, res) => {
  const { consumer_id, units_consumed } = req.body;
  const bill_amount = calculateBill(units_consumed);
  const bill_date = new Date();
  try {
    const [result] = await db.execute(
      'INSERT INTO billing (consumer_id, units_consumed, bill_amount, bill_date) VALUES (?, ?, ?, ?)',
      [consumer_id, units_consumed, bill_amount, bill_date]
    );
    res.json({ id: result.insertId, consumer_id, units_consumed, bill_amount, bill_date });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all consumers
app.get('/api/consumers', async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT * FROM consumer');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all billing records
app.get('/api/billing', async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT * FROM billing');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get billing records for a consumer
app.get('/api/billing/:consumer_id', async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT * FROM billing WHERE consumer_id = ?', [req.params.consumer_id]);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
