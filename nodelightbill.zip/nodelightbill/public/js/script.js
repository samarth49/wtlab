$(document).ready(function() {
  // Load consumers into dropdown
  function loadConsumers() {
    $.get('/api/consumers', function(data) {
      const select = $('#consumerSelect');
      select.empty().append('<option value="">Select Consumer</option>');
      data.forEach(c => {
        select.append(`<option value="${c.id}">${c.name} (${c.contact_number})</option>`);
      });
    });
  }

  // Load billing records
  function loadBilling() {
    $.get('/api/billing', function(data) {
      let html = '<table class="table table-bordered table-sm"><thead><tr><th>ID</th><th>Consumer ID</th><th>Units</th><th>Amount</th><th>Date</th></tr></thead><tbody>';
      data.forEach(b => {
        html += `<tr><td>${b.id}</td><td>${b.consumer_id}</td><td>${b.units_consumed}</td><td>₹${b.bill_amount}</td><td>${b.bill_date}</td></tr>`;
      });
      html += '</tbody></table>';
      $('#billingTableContainer').html(html);
    });
  }

  // Add consumer
  $('#consumerForm').submit(function(e) {
    e.preventDefault();
    const consumer = {
      name: $('#name').val(),
      address: $('#address').val(),
      contact_number: $('#contact_number').val(),
      email: $('#email').val()
    };
    $.post('/api/consumers', consumer, function() {
      loadConsumers();
      $('#consumerForm')[0].reset();
      alert('Consumer added!');
    });
  });

  // Calculate and add bill
  $('#billForm').submit(function(e) {
    e.preventDefault();
    const consumer_id = $('#consumerSelect').val();
    const units = $('#units').val();
    if (!consumer_id) return alert('Select a consumer');
    $.post('/api/billing', { consumer_id, units_consumed: units }, function(data) {
      $('#billResult').removeClass('d-none').text(`Bill Amount: ₹${data.bill_amount.toFixed(2)}`);
      loadBilling();
      $('#billForm')[0].reset();
    });
  });

  loadConsumers();
  loadBilling();
});
