$(document).ready(function() {
    // Load consumers when page loads
    loadConsumers();

    // Consumer Registration Form Submit
    $('#consumerForm').on('submit', function(e) {
        e.preventDefault();
        
        const consumerData = {
            name: $('#name').val(),
            address: $('#address').val(),
            meterNumber: $('#meterNumber').val(),
            contactNumber: $('#contactNumber').val(),
            email: $('#email').val()
        };

        $.ajax({
            url: '/api/consumers',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(consumerData),
            success: function(response) {
                alert('Consumer registered successfully!');
                $('#consumerForm')[0].reset();
                loadConsumers();
            },
            error: function(xhr, status, error) {
                alert('Error registering consumer: ' + error);
            }
        });
    });

    // Bill Calculation Form Submit
    $('#billForm').on('submit', function(e) {
        e.preventDefault();
        
        const units = $('#units').val();
        const consumerId = $('#consumerId').val();

        // First calculate the bill amount
        $.ajax({
            url: `/api/bills/calculate/${units}`,
            type: 'GET',
            success: function(billAmount) {
                const billData = {
                    consumer: { id: consumerId },
                    unitsConsumed: parseInt(units),
                    billAmount: billAmount,
                    billDate: new Date().toISOString().split('T')[0],
                    paid: false
                };

                // Then save the bill
                $.ajax({
                    url: '/api/bills',
                    type: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify(billData),
                    success: function(response) {
                        $('#billResult').html(`
                            <div class="alert alert-success">
                                <h5>Bill Details:</h5>
                                <p>Units Consumed: ${units}</p>
                                <p>Bill Amount: Rs. ${billAmount.toFixed(2)}</p>
                            </div>
                        `);
                    },
                    error: function(xhr, status, error) {
                        alert('Error saving bill: ' + error);
                    }
                });
            },
            error: function(xhr, status, error) {
                alert('Error calculating bill: ' + error);
            }
        });
    });

    function loadConsumers() {
        $.ajax({
            url: '/api/consumers',
            type: 'GET',
            success: function(consumers) {
                const select = $('#consumerId');
                select.empty();
                select.append('<option value="">Select a consumer</option>');
                consumers.forEach(consumer => {
                    select.append(`<option value="${consumer.id}">${consumer.name} - ${consumer.meterNumber}</option>`);
                });
            },
            error: function(xhr, status, error) {
                alert('Error loading consumers: ' + error);
            }
        });
    }
});
