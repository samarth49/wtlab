package com.example.demo.service;

import com.example.demo.model.Consumer;
import com.example.demo.repository.ConsumerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ConsumerService {
    @Autowired
    private ConsumerRepository consumerRepository;

    public Consumer saveConsumer(Consumer consumer) {
        return consumerRepository.save(consumer);
    }

    public List<Consumer> getAllConsumers() {
        return consumerRepository.findAll();
    }

    public Consumer getConsumerById(Long id) {
        return consumerRepository.findById(id).orElse(null);
    }
}
