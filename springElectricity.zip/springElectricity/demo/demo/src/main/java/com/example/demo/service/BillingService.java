package com.example.demo.service;

import com.example.demo.model.Billing;
import com.example.demo.repository.BillingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BillingService {
    @Autowired
    private BillingRepository billingRepository;

    public double calculateBill(int units) {
        double amount = 0;
        
        // First 50 units - Rs. 3.50/unit
        if (units <= 50) {
            amount = units * 3.50;
        }
        // Next 100 units - Rs. 4.00/unit
        else if (units <= 150) {
            amount = (50 * 3.50) + ((units - 50) * 4.00);
        }
        // Next 100 units - Rs. 5.20/unit
        else if (units <= 250) {
            amount = (50 * 3.50) + (100 * 4.00) + ((units - 150) * 5.20);
        }
        // Above 250 units - Rs. 6.50/unit
        else {
            amount = (50 * 3.50) + (100 * 4.00) + (100 * 5.20) + ((units - 250) * 6.50);
        }
        
        return amount;
    }

    public Billing saveBill(Billing billing) {
        billing.setBillAmount(calculateBill(billing.getUnitsConsumed()));
        return billingRepository.save(billing);
    }
}
