package com.example.demo.controller;

import com.example.demo.model.Billing;
import com.example.demo.service.BillingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bills")
@CrossOrigin(origins = "*")
public class BillingController {
    @Autowired
    private BillingService billingService;

    @PostMapping
    public ResponseEntity<Billing> createBill(@RequestBody Billing billing) {
        return ResponseEntity.ok(billingService.saveBill(billing));
    }

    @GetMapping("/calculate/{units}")
    public ResponseEntity<Double> calculateBill(@PathVariable int units) {
        return ResponseEntity.ok(billingService.calculateBill(units));
    }
}
