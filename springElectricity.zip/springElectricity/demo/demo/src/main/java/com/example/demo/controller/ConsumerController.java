package com.example.demo.controller;

import com.example.demo.model.Consumer;
import com.example.demo.service.ConsumerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/consumers")
@CrossOrigin(origins = "*")
public class ConsumerController {
    @Autowired
    private ConsumerService consumerService;

    @PostMapping
    public ResponseEntity<Consumer> createConsumer(@RequestBody Consumer consumer) {
        return ResponseEntity.ok(consumerService.saveConsumer(consumer));
    }

    @GetMapping
    public ResponseEntity<List<Consumer>> getAllConsumers() {
        return ResponseEntity.ok(consumerService.getAllConsumers());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Consumer> getConsumerById(@PathVariable Long id) {
        Consumer consumer = consumerService.getConsumerById(id);
        if (consumer != null) {
            return ResponseEntity.ok(consumer);
        }
        return ResponseEntity.notFound().build();
    }
}
