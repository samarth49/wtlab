package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Data
public class Billing {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "consumer_id")
    private Consumer consumer;
    
    private LocalDate billDate;
    private int unitsConsumed;
    private double billAmount;
    private boolean isPaid;
}
