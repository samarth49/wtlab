// Node class for the Binary Search Tree
class Node {
    constructor(value) {
        this.value = value;
        this.left = null;
        this.right = null;
    }
}

// Binary Search Tree class
class BinarySearchTree {
    constructor() {
        this.root = null;
    }

    // Insert a new value into the tree
    insert(value) {
        const newNode = new Node(value);

        if (this.root === null) {
            this.root = newNode;
            return;
        }

        let current = this.root;
        while (true) {
            if (value < current.value) {
                if (current.left === null) {
                    current.left = newNode;
                    break;
                }
                current = current.left;
            } else {
                if (current.right === null) {
                    current.right = newNode;
                    break;
                }
                current = current.right;
            }
        }
        this.updateVisualization();
    }

    // Breadth First Search
    bfs() {
        const result = [];
        const queue = [];
        
        if (!this.root) return result;
        
        queue.push(this.root);
        
        while (queue.length) {
            const node = queue.shift();
            result.push(node.value);
            
            if (node.left) queue.push(node.left);
            if (node.right) queue.push(node.right);
        }
        
        return result;
    }

    // Depth First Search (In-order traversal)
    dfs() {
        const result = [];
        
        function traverse(node) {
            if (node.left) traverse(node.left);
            result.push(node.value);
            if (node.right) traverse(node.right);
        }
        
        if (this.root) traverse(this.root);
        return result;
    }

    // Get sorted array (in-order traversal)
    getSortedArray() {
        return this.dfs();
    }

    // Visualize the tree
    updateVisualization() {
        const treeDisplay = document.getElementById('treeDisplay');
        treeDisplay.innerHTML = '';

        if (!this.root) return;

        const queue = [{ node: this.root, level: 0, position: 0 }];
        const levels = {};

        while (queue.length > 0) {
            const { node, level, position } = queue.shift();

            if (!levels[level]) {
                levels[level] = [];
            }

            levels[level].push({ value: node.value, position });

            if (node.left) {
                queue.push({ node: node.left, level: level + 1, position: position * 2 });
            }
            if (node.right) {
                queue.push({ node: node.right, level: level + 1, position: position * 2 + 1 });
            }
        }

        Object.keys(levels).forEach(level => {
            const levelDiv = document.createElement('div');
            levelDiv.style.display = 'flex';
            levelDiv.style.justifyContent = 'center';
            levelDiv.style.margin = '10px 0';

            levels[level].forEach(node => {
                const nodeDiv = document.createElement('div');
                nodeDiv.className = 'node';
                nodeDiv.textContent = node.value;
                levelDiv.appendChild(nodeDiv);
            });

            treeDisplay.appendChild(levelDiv);
        });
    }
}

// Initialize the tree
let bst = new BinarySearchTree();

// Function to insert a number
function insertNumber() {
    const input = document.getElementById('numberInput');
    const value = parseInt(input.value);
    
    if (!isNaN(value)) {
        bst.insert(value);
        input.value = '';
        document.getElementById('searchResult').textContent = '';
        document.getElementById('sortedResult').textContent = '';
    }
}

// Function to perform BFS
function performBFS() {
    const result = bst.bfs();
    document.getElementById('searchResult').textContent = 'BFS Result: ' + result.join(' → ');
}

// Function to perform DFS
function performDFS() {
    const result = bst.dfs();
    document.getElementById('searchResult').textContent = 'DFS Result: ' + result.join(' → ');
}

// Function to sort the tree
function sortTree() {
    const sorted = bst.getSortedArray();
    document.getElementById('sortedResult').textContent = 'Sorted Array: ' + sorted.join(' → ');
}

// Function to clear the tree
function clearTree() {
    bst = new BinarySearchTree();
    document.getElementById('treeDisplay').innerHTML = '';
    document.getElementById('searchResult').textContent = '';
    document.getElementById('sortedResult').textContent = '';
}
